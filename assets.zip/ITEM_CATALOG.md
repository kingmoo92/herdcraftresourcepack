# HerdCraft Resource Pack - Complete Item Catalog

**Pack Format:** 84 (Minecraft Java Edition 26.1.2)
**Total Items:** 418
**Credits:** MrBoriiz Cosmetics (CC BY-NC-ND 4.0), HerdCraft originals, Sebxter hats

## How to Use

### In-Game Menu
Run `/function herdcraft:menu/main` to open the interactive item browser.

### Direct Give Commands
Each item can be given with a function command:
```
/function herdcraft:give/<category>/<item_name>
```

### Manual Give (for reference)
```
/give @s carved_pumpkin[item_model="herdcraft:boriiz/<item_name>",custom_name={text:"Display Name",italic:false}] 1
```

---

## Among Us (16 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Amongus Black | carved_pumpkin | `/function herdcraft:give/among_us/amongus_black` |
| Amongus Blue | carved_pumpkin | `/function herdcraft:give/among_us/amongus_blue` |
| Amongus Brown | carved_pumpkin | `/function herdcraft:give/among_us/amongus_brown` |
| Amongus Cyan | carved_pumpkin | `/function herdcraft:give/among_us/amongus_cyan` |
| Amongus Gray | carved_pumpkin | `/function herdcraft:give/among_us/amongus_gray` |
| Amongus Green | carved_pumpkin | `/function herdcraft:give/among_us/amongus_green` |
| Amongus Light Blue | carved_pumpkin | `/function herdcraft:give/among_us/amongus_light_blue` |
| Amongus Light Gray | carved_pumpkin | `/function herdcraft:give/among_us/amongus_light_gray` |
| Amongus Lime | carved_pumpkin | `/function herdcraft:give/among_us/amongus_lime` |
| Amongus Magenta | carved_pumpkin | `/function herdcraft:give/among_us/amongus_magenta` |
| Amongus Orange | carved_pumpkin | `/function herdcraft:give/among_us/amongus_orange` |
| Amongus Pink | carved_pumpkin | `/function herdcraft:give/among_us/amongus_pink` |
| Amongus Purple | carved_pumpkin | `/function herdcraft:give/among_us/amongus_purple` |
| Amongus Red | carved_pumpkin | `/function herdcraft:give/among_us/amongus_red` |
| Amongus White | carved_pumpkin | `/function herdcraft:give/among_us/amongus_white` |
| Amongus Yellow | carved_pumpkin | `/function herdcraft:give/among_us/amongus_yellow` |

## Animals (6 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Bunny Ears | carved_pumpkin | `/function herdcraft:give/animals/bunny_ears` |
| Cat Ears | carved_pumpkin | `/function herdcraft:give/animals/cat_ears` |
| Fox Ears | carved_pumpkin | `/function herdcraft:give/animals/fox_ears` |
| Owl Ears | carved_pumpkin | `/function herdcraft:give/animals/owl_ears` |
| White Owl Ears | carved_pumpkin | `/function herdcraft:give/animals/white_owl_ears` |
| Wolf Ears | carved_pumpkin | `/function herdcraft:give/animals/wolf_ears` |

## Caps (16 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Cap Black | carved_pumpkin | `/function herdcraft:give/caps/cap_black` |
| Cap Blue | carved_pumpkin | `/function herdcraft:give/caps/cap_blue` |
| Cap Brown | carved_pumpkin | `/function herdcraft:give/caps/cap_brown` |
| Cap Cyan | carved_pumpkin | `/function herdcraft:give/caps/cap_cyan` |
| Cap Gray | carved_pumpkin | `/function herdcraft:give/caps/cap_gray` |
| Cap Green | carved_pumpkin | `/function herdcraft:give/caps/cap_green` |
| Cap Light Blue | carved_pumpkin | `/function herdcraft:give/caps/cap_light_blue` |
| Cap Light Gray | carved_pumpkin | `/function herdcraft:give/caps/cap_light_gray` |
| Cap Lime | carved_pumpkin | `/function herdcraft:give/caps/cap_lime` |
| Cap Magenta | carved_pumpkin | `/function herdcraft:give/caps/cap_magenta` |
| Cap Orange | carved_pumpkin | `/function herdcraft:give/caps/cap_orange` |
| Cap Pink | carved_pumpkin | `/function herdcraft:give/caps/cap_pink` |
| Cap Purple | carved_pumpkin | `/function herdcraft:give/caps/cap_purple` |
| Cap Red | carved_pumpkin | `/function herdcraft:give/caps/cap_red` |
| Cap White | carved_pumpkin | `/function herdcraft:give/caps/cap_white` |
| Cap Yellow | carved_pumpkin | `/function herdcraft:give/caps/cap_yellow` |

## Christmas (8 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Candy Cane Green | carved_pumpkin | `/function herdcraft:give/christmas/candy_cane_green` |
| Candy Cane Red | carved_pumpkin | `/function herdcraft:give/christmas/candy_cane_red` |
| Christmas Tree Big | command_block | `/function herdcraft:give/christmas/christmas_tree_big` |
| Christmas Tree Little | command_block | `/function herdcraft:give/christmas/christmas_tree_little` |
| Christmas Tree Medium | command_block | `/function herdcraft:give/christmas/christmas_tree_medium` |
| Elf | carved_pumpkin | `/function herdcraft:give/christmas/elf` |
| Elf Ears | carved_pumpkin | `/function herdcraft:give/christmas/elf_ears` |
| Santa | carved_pumpkin | `/function herdcraft:give/christmas/santa` |

## Crowns (5 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| British Crown | carved_pumpkin | `/function herdcraft:give/crowns/british_crown` |
| Golden Crown | carved_pumpkin | `/function herdcraft:give/crowns/golden_crown` |
| King Crown | carved_pumpkin | `/function herdcraft:give/crowns/king_crown` |
| Silver Crown | carved_pumpkin | `/function herdcraft:give/crowns/silver_crown` |
| Technoblade Crown | carved_pumpkin | `/function herdcraft:give/crowns/technoblade_crown` |

## FNAF (11 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Bonnie | carved_pumpkin | `/function herdcraft:give/fnaf/bonnie` |
| Bonnie Be | carved_pumpkin | `/function herdcraft:give/fnaf/bonnie_be` |
| Chica | carved_pumpkin | `/function herdcraft:give/fnaf/chica` |
| Chica Be | carved_pumpkin | `/function herdcraft:give/fnaf/chica_be` |
| Foxy | carved_pumpkin | `/function herdcraft:give/fnaf/foxy` |
| Foxy Be | carved_pumpkin | `/function herdcraft:give/fnaf/foxy_be` |
| Freddy Fazbear | carved_pumpkin | `/function herdcraft:give/fnaf/freddy_fazbear` |
| Freddy Fazbear Be | carved_pumpkin | `/function herdcraft:give/fnaf/freddy_fazbear_be` |
| Freddy Mask | carved_pumpkin | `/function herdcraft:give/fnaf/freddy_mask` |
| Golden Freddy | carved_pumpkin | `/function herdcraft:give/fnaf/golden_freddy` |
| Golden Freddy No Eyes | carved_pumpkin | `/function herdcraft:give/fnaf/golden_freddy_no_eyes` |

## Fedoras (16 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Fedora Black | carved_pumpkin | `/function herdcraft:give/fedoras/fedora_black` |
| Fedora Blue | carved_pumpkin | `/function herdcraft:give/fedoras/fedora_blue` |
| Fedora Brown | carved_pumpkin | `/function herdcraft:give/fedoras/fedora_brown` |
| Fedora Cyan | carved_pumpkin | `/function herdcraft:give/fedoras/fedora_cyan` |
| Fedora Gray | carved_pumpkin | `/function herdcraft:give/fedoras/fedora_gray` |
| Fedora Green | carved_pumpkin | `/function herdcraft:give/fedoras/fedora_green` |
| Fedora Light Blue | carved_pumpkin | `/function herdcraft:give/fedoras/fedora_light_blue` |
| Fedora Light Gray | carved_pumpkin | `/function herdcraft:give/fedoras/fedora_light_gray` |
| Fedora Lime | carved_pumpkin | `/function herdcraft:give/fedoras/fedora_lime` |
| Fedora Magenta | carved_pumpkin | `/function herdcraft:give/fedoras/fedora_magenta` |
| Fedora Orange | carved_pumpkin | `/function herdcraft:give/fedoras/fedora_orange` |
| Fedora Pink | carved_pumpkin | `/function herdcraft:give/fedoras/fedora_pink` |
| Fedora Purple | carved_pumpkin | `/function herdcraft:give/fedoras/fedora_purple` |
| Fedora Red | carved_pumpkin | `/function herdcraft:give/fedoras/fedora_red` |
| Fedora White | carved_pumpkin | `/function herdcraft:give/fedoras/fedora_white` |
| Fedora Yellow | carved_pumpkin | `/function herdcraft:give/fedoras/fedora_yellow` |

## Fishing Rods (3 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Fishing Rod Amethyst | carved_pumpkin | `/function herdcraft:give/fishing_rods/fishing_rod_amethyst` |
| Fishing Rod Diamond | carved_pumpkin | `/function herdcraft:give/fishing_rods/fishing_rod_diamond` |
| Fishing Rod Emerald | carved_pumpkin | `/function herdcraft:give/fishing_rods/fishing_rod_emerald` |

## Gaming Headsets (17 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Gaming Headset Black | carved_pumpkin | `/function herdcraft:give/gaming_headsets/gaming_headset_black` |
| Gaming Headset Blue | carved_pumpkin | `/function herdcraft:give/gaming_headsets/gaming_headset_blue` |
| Gaming Headset Brown | carved_pumpkin | `/function herdcraft:give/gaming_headsets/gaming_headset_brown` |
| Gaming Headset Cyan | carved_pumpkin | `/function herdcraft:give/gaming_headsets/gaming_headset_cyan` |
| Gaming Headset Gray | carved_pumpkin | `/function herdcraft:give/gaming_headsets/gaming_headset_gray` |
| Gaming Headset Green | carved_pumpkin | `/function herdcraft:give/gaming_headsets/gaming_headset_green` |
| Gaming Headset Light Blue | carved_pumpkin | `/function herdcraft:give/gaming_headsets/gaming_headset_light_blue` |
| Gaming Headset Light Gray | carved_pumpkin | `/function herdcraft:give/gaming_headsets/gaming_headset_light_gray` |
| Gaming Headset Lime | carved_pumpkin | `/function herdcraft:give/gaming_headsets/gaming_headset_lime` |
| Gaming Headset Magenta | carved_pumpkin | `/function herdcraft:give/gaming_headsets/gaming_headset_magenta` |
| Gaming Headset Orange | carved_pumpkin | `/function herdcraft:give/gaming_headsets/gaming_headset_orange` |
| Gaming Headset Pink | carved_pumpkin | `/function herdcraft:give/gaming_headsets/gaming_headset_pink` |
| Gaming Headset Purple | carved_pumpkin | `/function herdcraft:give/gaming_headsets/gaming_headset_purple` |
| Gaming Headset Red | carved_pumpkin | `/function herdcraft:give/gaming_headsets/gaming_headset_red` |
| Gaming Headset Rgb | carved_pumpkin | `/function herdcraft:give/gaming_headsets/gaming_headset_rgb` |
| Gaming Headset White | carved_pumpkin | `/function herdcraft:give/gaming_headsets/gaming_headset_white` |
| Gaming Headset Yellow | carved_pumpkin | `/function herdcraft:give/gaming_headsets/gaming_headset_yellow` |

## Hazbin Hotel (33 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Adam Full Mask Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/adam_full_mask_hazbin` |
| Adam Full White Mask Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/adam_full_white_mask_hazbin` |
| Adam Halo Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/adam_halo_hazbin` |
| Adam Halo Mask Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/adam_halo_mask_hazbin` |
| Adam Mask Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/adam_mask_hazbin` |
| Alastor Ears Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/alastor_ears_hazbin` |
| Alastor Monocle Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/alastor_monocle_hazbin` |
| Angel Dust Hair Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/angel_dust_hair_hazbin` |
| Angel Dust Hair Sunglasses Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/angel_dust_hair_sunglasses_hazbin` |
| Angel Dust Sunglasses Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/angel_dust_sunglasses_hazbin` |
| Emily Halo Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/emily_halo_hazbin` |
| Exorcist Full Mask Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/exorcist_full_mask_hazbin` |
| Exorcist Halo Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/exorcist_halo_hazbin` |
| Exorcist Halo Mask Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/exorcist_halo_mask_hazbin` |
| Exorcist Mask Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/exorcist_mask_hazbin` |
| Husk Ears Hat Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/husk_ears_hat_hazbin` |
| Husk Ears Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/husk_ears_hazbin` |
| Husk Eyebrows Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/husk_eyebrows_hazbin` |
| Husk Full Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/husk_full_hazbin` |
| Husk Hat Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/husk_hat_hazbin` |
| Lucifer Hat Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/lucifer_hat_hazbin` |
| Lute Full Mask Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/lute_full_mask_hazbin` |
| Lute Halo Mask Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/lute_halo_mask_hazbin` |
| Lute Mask Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/lute_mask_hazbin` |
| Vaggie Loop Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/vaggie_loop_hazbin` |
| Vaggie X Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/vaggie_x_hazbin` |
| Vaggie X Loop Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/vaggie_x_loop_hazbin` |
| Valentino Hat Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/valentino_hat_hazbin` |
| Valentino Hat Sunglasses Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/valentino_hat_sunglasses_hazbin` |
| Valentino Sunglasses Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/valentino_sunglasses_hazbin` |
| Vox Full Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/vox_full_hazbin` |
| Vox Hat Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/vox_hat_hazbin` |
| Vox Head Hazbin | carved_pumpkin | `/function herdcraft:give/hazbin_hotel/vox_head_hazbin` |

## Head Pickaxes (6 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Pickaxe Diamond | carved_pumpkin | `/function herdcraft:give/head_pickaxes/pickaxe_diamond` |
| Pickaxe Gold | carved_pumpkin | `/function herdcraft:give/head_pickaxes/pickaxe_gold` |
| Pickaxe Iron | carved_pumpkin | `/function herdcraft:give/head_pickaxes/pickaxe_iron` |
| Pickaxe Netherite | carved_pumpkin | `/function herdcraft:give/head_pickaxes/pickaxe_netherite` |
| Pickaxe Stone | carved_pumpkin | `/function herdcraft:give/head_pickaxes/pickaxe_stone` |
| Pickaxe Wood | carved_pumpkin | `/function herdcraft:give/head_pickaxes/pickaxe_wood` |

## Headphones (17 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Headphones Black | carved_pumpkin | `/function herdcraft:give/headphones/headphones_black` |
| Headphones Blue | carved_pumpkin | `/function herdcraft:give/headphones/headphones_blue` |
| Headphones Brown | carved_pumpkin | `/function herdcraft:give/headphones/headphones_brown` |
| Headphones Cyan | carved_pumpkin | `/function herdcraft:give/headphones/headphones_cyan` |
| Headphones Gray | carved_pumpkin | `/function herdcraft:give/headphones/headphones_gray` |
| Headphones Green | carved_pumpkin | `/function herdcraft:give/headphones/headphones_green` |
| Headphones Light Blue | carved_pumpkin | `/function herdcraft:give/headphones/headphones_light_blue` |
| Headphones Light Gray | carved_pumpkin | `/function herdcraft:give/headphones/headphones_light_gray` |
| Headphones Lime | carved_pumpkin | `/function herdcraft:give/headphones/headphones_lime` |
| Headphones Magenta | carved_pumpkin | `/function herdcraft:give/headphones/headphones_magenta` |
| Headphones Orange | carved_pumpkin | `/function herdcraft:give/headphones/headphones_orange` |
| Headphones Pink | carved_pumpkin | `/function herdcraft:give/headphones/headphones_pink` |
| Headphones Plain | carved_pumpkin | `/function herdcraft:give/headphones/headphones_plain` |
| Headphones Purple | carved_pumpkin | `/function herdcraft:give/headphones/headphones_purple` |
| Headphones Red | carved_pumpkin | `/function herdcraft:give/headphones/headphones_red` |
| Headphones White | carved_pumpkin | `/function herdcraft:give/headphones/headphones_white` |
| Headphones Yellow | carved_pumpkin | `/function herdcraft:give/headphones/headphones_yellow` |

## HerdCraft Originals (18 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Antennas | carved_pumpkin | `/function herdcraft:give/herdcraft_originals/antennas` |
| Cheese | pumpkin_pie | `/function herdcraft:give/herdcraft_originals/cheese` |
| Cheese Pizza | pumpkin_pie | `/function herdcraft:give/herdcraft_originals/cheese_pizza` |
| Cheesewheel | pumpkin_pie | `/function herdcraft:give/herdcraft_originals/cheesewheel` |
| Gloria | carved_pumpkin | `/function herdcraft:give/herdcraft_originals/gloria` |
| Grilled Cheese | cooked_porkchop | `/function herdcraft:give/herdcraft_originals/grilled_cheese` |
| Hat Green | carved_pumpkin | `/function herdcraft:give/herdcraft_originals/hat_green` |
| Hat Santa | carved_pumpkin | `/function herdcraft:give/herdcraft_originals/hat_santa` |
| Landland Icecream | beetroot_soup | `/function herdcraft:give/herdcraft_originals/landland_icecream` |
| Lollipop | pumpkin_pie | `/function herdcraft:give/herdcraft_originals/lollipop` |
| Mobile Router | shield | `/function herdcraft:give/herdcraft_originals/mobile_router` |
| Moos Extra Life | totem_of_undying | `/function herdcraft:give/herdcraft_originals/moos_extra_life` |
| Mooshroom Hat | carved_pumpkin | `/function herdcraft:give/herdcraft_originals/mooshroom_hat` |
| Party Popper | totem_of_undying | `/function herdcraft:give/herdcraft_originals/party_popper` |
| Penguin | totem_of_undying | `/function herdcraft:give/herdcraft_originals/penguin` |
| Professor Hair | carved_pumpkin | `/function herdcraft:give/herdcraft_originals/professor_hair` |
| Rainbow Pig Hat | carved_pumpkin | `/function herdcraft:give/herdcraft_originals/rainbow_pig_hat` |
| Totem Of Bobo | totem_of_undying | `/function herdcraft:give/herdcraft_originals/totem_of_bobo` |

## Large Presents (16 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Large Present Black | carved_pumpkin | `/function herdcraft:give/large_presents/large_present_black` |
| Large Present Blue | carved_pumpkin | `/function herdcraft:give/large_presents/large_present_blue` |
| Large Present Brown | carved_pumpkin | `/function herdcraft:give/large_presents/large_present_brown` |
| Large Present Cyan | carved_pumpkin | `/function herdcraft:give/large_presents/large_present_cyan` |
| Large Present Gray | carved_pumpkin | `/function herdcraft:give/large_presents/large_present_gray` |
| Large Present Green | carved_pumpkin | `/function herdcraft:give/large_presents/large_present_green` |
| Large Present Light Blue | carved_pumpkin | `/function herdcraft:give/large_presents/large_present_light_blue` |
| Large Present Light Gray | carved_pumpkin | `/function herdcraft:give/large_presents/large_present_light_gray` |
| Large Present Lime | carved_pumpkin | `/function herdcraft:give/large_presents/large_present_lime` |
| Large Present Magenta | carved_pumpkin | `/function herdcraft:give/large_presents/large_present_magenta` |
| Large Present Orange | carved_pumpkin | `/function herdcraft:give/large_presents/large_present_orange` |
| Large Present Pink | carved_pumpkin | `/function herdcraft:give/large_presents/large_present_pink` |
| Large Present Purple | carved_pumpkin | `/function herdcraft:give/large_presents/large_present_purple` |
| Large Present Red | carved_pumpkin | `/function herdcraft:give/large_presents/large_present_red` |
| Large Present White | carved_pumpkin | `/function herdcraft:give/large_presents/large_present_white` |
| Large Present Yellow | carved_pumpkin | `/function herdcraft:give/large_presents/large_present_yellow` |

## Masks (34 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Alex Mask | carved_pumpkin | `/function herdcraft:give/masks/alex_mask` |
| Classic Enderman Mask | carved_pumpkin | `/function herdcraft:give/masks/classic_enderman_mask` |
| Creeper Mask | carved_pumpkin | `/function herdcraft:give/masks/creeper_mask` |
| Dali Mask | carved_pumpkin | `/function herdcraft:give/masks/dali_mask` |
| Drowned Mask | carved_pumpkin | `/function herdcraft:give/masks/drowned_mask` |
| Enderman Mask | carved_pumpkin | `/function herdcraft:give/masks/enderman_mask` |
| Herobrine Mask | carved_pumpkin | `/function herdcraft:give/masks/herobrine_mask` |
| Husk Mask | carved_pumpkin | `/function herdcraft:give/masks/husk_mask` |
| Mask Blow | carved_pumpkin | `/function herdcraft:give/masks/mask_blow` |
| Mask Bremu | carved_pumpkin | `/function herdcraft:give/masks/mask_bremu` |
| Mask Eleven | carved_pumpkin | `/function herdcraft:give/masks/mask_eleven` |
| Mask Jdabrowsky | carved_pumpkin | `/function herdcraft:give/masks/mask_jdabrowsky` |
| Mask Jjayjoker | carved_pumpkin | `/function herdcraft:give/masks/mask_jjayjoker` |
| Mask Ljay | carved_pumpkin | `/function herdcraft:give/masks/mask_ljay` |
| Mask Madzik89 | carved_pumpkin | `/function herdcraft:give/masks/mask_madzik89` |
| Mask Mrboriiz | carved_pumpkin | `/function herdcraft:give/masks/mask_mrboriiz` |
| Mask Multi | carved_pumpkin | `/function herdcraft:give/masks/mask_multi` |
| Mask Ognisty | carved_pumpkin | `/function herdcraft:give/masks/mask_ognisty` |
| Mask Pansmietanka | carved_pumpkin | `/function herdcraft:give/masks/mask_pansmietanka` |
| Mask Polskipingwin | carved_pumpkin | `/function herdcraft:give/masks/mask_polskipingwin` |
| Mask Revisza | carved_pumpkin | `/function herdcraft:give/masks/mask_revisza` |
| Mask Rezi | carved_pumpkin | `/function herdcraft:give/masks/mask_rezi` |
| Mask Roxmb | carved_pumpkin | `/function herdcraft:give/masks/mask_roxmb` |
| Mask Skkf | carved_pumpkin | `/function herdcraft:give/masks/mask_skkf` |
| Mask Vertez | carved_pumpkin | `/function herdcraft:give/masks/mask_vertez` |
| Rock Mask | carved_pumpkin | `/function herdcraft:give/masks/rock_mask` |
| Skeleton Mask | carved_pumpkin | `/function herdcraft:give/masks/skeleton_mask` |
| Steve Mask | carved_pumpkin | `/function herdcraft:give/masks/steve_mask` |
| Stray Mask | carved_pumpkin | `/function herdcraft:give/masks/stray_mask` |
| Technoblade Mask | carved_pumpkin | `/function herdcraft:give/masks/technoblade_mask` |
| Villager Mask | carved_pumpkin | `/function herdcraft:give/masks/villager_mask` |
| Wither Mask | carved_pumpkin | `/function herdcraft:give/masks/wither_mask` |
| Wither Skeleton Mask | carved_pumpkin | `/function herdcraft:give/masks/wither_skeleton_mask` |
| Zombie Mask | carved_pumpkin | `/function herdcraft:give/masks/zombie_mask` |

## Medium Presents (16 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Medium Present Black | carved_pumpkin | `/function herdcraft:give/medium_presents/medium_present_black` |
| Medium Present Blue | carved_pumpkin | `/function herdcraft:give/medium_presents/medium_present_blue` |
| Medium Present Brown | carved_pumpkin | `/function herdcraft:give/medium_presents/medium_present_brown` |
| Medium Present Cyan | carved_pumpkin | `/function herdcraft:give/medium_presents/medium_present_cyan` |
| Medium Present Gray | carved_pumpkin | `/function herdcraft:give/medium_presents/medium_present_gray` |
| Medium Present Green | carved_pumpkin | `/function herdcraft:give/medium_presents/medium_present_green` |
| Medium Present Light Blue | carved_pumpkin | `/function herdcraft:give/medium_presents/medium_present_light_blue` |
| Medium Present Light Gray | carved_pumpkin | `/function herdcraft:give/medium_presents/medium_present_light_gray` |
| Medium Present Lime | carved_pumpkin | `/function herdcraft:give/medium_presents/medium_present_lime` |
| Medium Present Magenta | carved_pumpkin | `/function herdcraft:give/medium_presents/medium_present_magenta` |
| Medium Present Orange | carved_pumpkin | `/function herdcraft:give/medium_presents/medium_present_orange` |
| Medium Present Pink | carved_pumpkin | `/function herdcraft:give/medium_presents/medium_present_pink` |
| Medium Present Purple | carved_pumpkin | `/function herdcraft:give/medium_presents/medium_present_purple` |
| Medium Present Red | carved_pumpkin | `/function herdcraft:give/medium_presents/medium_present_red` |
| Medium Present White | carved_pumpkin | `/function herdcraft:give/medium_presents/medium_present_white` |
| Medium Present Yellow | carved_pumpkin | `/function herdcraft:give/medium_presents/medium_present_yellow` |

## Mini Blocks (14 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Mini Block Anvil | carved_pumpkin | `/function herdcraft:give/mini_blocks/mini_block_anvil` |
| Mini Block Barrel | carved_pumpkin | `/function herdcraft:give/mini_blocks/mini_block_barrel` |
| Mini Block Blast Furnace | carved_pumpkin | `/function herdcraft:give/mini_blocks/mini_block_blast_furnace` |
| Mini Block Chest | carved_pumpkin | `/function herdcraft:give/mini_blocks/mini_block_chest` |
| Mini Block Crafting | carved_pumpkin | `/function herdcraft:give/mini_blocks/mini_block_crafting` |
| Mini Block Enchant | carved_pumpkin | `/function herdcraft:give/mini_blocks/mini_block_enchant` |
| Mini Block Ender Chest | carved_pumpkin | `/function herdcraft:give/mini_blocks/mini_block_ender_chest` |
| Mini Block Furnace | carved_pumpkin | `/function herdcraft:give/mini_blocks/mini_block_furnace` |
| Mini Block Hopper | carved_pumpkin | `/function herdcraft:give/mini_blocks/mini_block_hopper` |
| Mini Block Loom | carved_pumpkin | `/function herdcraft:give/mini_blocks/mini_block_loom` |
| Mini Block Piston | carved_pumpkin | `/function herdcraft:give/mini_blocks/mini_block_piston` |
| Mini Block Smoker | carved_pumpkin | `/function herdcraft:give/mini_blocks/mini_block_smoker` |
| Mini Block Sticky Piston | carved_pumpkin | `/function herdcraft:give/mini_blocks/mini_block_sticky_piston` |
| Mini Block Stonecutter | carved_pumpkin | `/function herdcraft:give/mini_blocks/mini_block_stonecutter` |

## Money System (34 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Bucks Case Closed Empty | command_block | `/function herdcraft:give/money_system/bucks_case_closed_empty` |
| Bucks Case Closed Five Thousand | command_block | `/function herdcraft:give/money_system/bucks_case_closed_five_thousand` |
| Bucks Case Opened Empty | command_block | `/function herdcraft:give/money_system/bucks_case_opened_empty` |
| Bucks Case Opened Five Thousand | command_block | `/function herdcraft:give/money_system/bucks_case_opened_five_thousand` |
| Bucks Case Opened Four Thousand | command_block | `/function herdcraft:give/money_system/bucks_case_opened_four_thousand` |
| Bucks Case Opened Gold Ingot Five | command_block | `/function herdcraft:give/money_system/bucks_case_opened_gold_ingot_five` |
| Bucks Case Opened Gold Ingot Four | command_block | `/function herdcraft:give/money_system/bucks_case_opened_gold_ingot_four` |
| Bucks Case Opened Gold Ingot One | command_block | `/function herdcraft:give/money_system/bucks_case_opened_gold_ingot_one` |
| Bucks Case Opened Gold Ingot Seven | command_block | `/function herdcraft:give/money_system/bucks_case_opened_gold_ingot_seven` |
| Bucks Case Opened Gold Ingot Six | command_block | `/function herdcraft:give/money_system/bucks_case_opened_gold_ingot_six` |
| Bucks Case Opened Gold Ingot Three | command_block | `/function herdcraft:give/money_system/bucks_case_opened_gold_ingot_three` |
| Bucks Case Opened Gold Ingot Two | command_block | `/function herdcraft:give/money_system/bucks_case_opened_gold_ingot_two` |
| Bucks Case Opened One Thousand | command_block | `/function herdcraft:give/money_system/bucks_case_opened_one_thousand` |
| Bucks Case Opened Three Thousand | command_block | `/function herdcraft:give/money_system/bucks_case_opened_three_thousand` |
| Bucks Case Opened Two Thousand | command_block | `/function herdcraft:give/money_system/bucks_case_opened_two_thousand` |
| Bucks Fifty | command_block | `/function herdcraft:give/money_system/bucks_fifty` |
| Bucks Five | command_block | `/function herdcraft:give/money_system/bucks_five` |
| Bucks Five Hundred | command_block | `/function herdcraft:give/money_system/bucks_five_hundred` |
| Bucks Gold Ingot Five | command_block | `/function herdcraft:give/money_system/bucks_gold_ingot_five` |
| Bucks Gold Ingot Four | command_block | `/function herdcraft:give/money_system/bucks_gold_ingot_four` |
| Bucks Gold Ingot One | command_block | `/function herdcraft:give/money_system/bucks_gold_ingot_one` |
| Bucks Gold Ingot Seven | command_block | `/function herdcraft:give/money_system/bucks_gold_ingot_seven` |
| Bucks Gold Ingot Six | command_block | `/function herdcraft:give/money_system/bucks_gold_ingot_six` |
| Bucks Gold Ingot Three | command_block | `/function herdcraft:give/money_system/bucks_gold_ingot_three` |
| Bucks Gold Ingot Two | command_block | `/function herdcraft:give/money_system/bucks_gold_ingot_two` |
| Bucks Hundred | command_block | `/function herdcraft:give/money_system/bucks_hundred` |
| Bucks One | command_block | `/function herdcraft:give/money_system/bucks_one` |
| Bucks Stack | command_block | `/function herdcraft:give/money_system/bucks_stack` |
| Bucks Ten | command_block | `/function herdcraft:give/money_system/bucks_ten` |
| Bucks Ten Thousand | command_block | `/function herdcraft:give/money_system/bucks_ten_thousand` |
| Cash Bag | command_block | `/function herdcraft:give/money_system/cash_bag` |
| Coin Copper | command_block | `/function herdcraft:give/money_system/coin_copper` |
| Coin Gold | command_block | `/function herdcraft:give/money_system/coin_gold` |
| Coin Silver | command_block | `/function herdcraft:give/money_system/coin_silver` |

## SCP Cosmetics (10 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Chaos Helmet | carved_pumpkin | `/function herdcraft:give/scp_cosmetics/chaos_helmet` |
| Gas Mask | carved_pumpkin | `/function herdcraft:give/scp_cosmetics/gas_mask` |
| Mtf Helmet | carved_pumpkin | `/function herdcraft:give/scp_cosmetics/mtf_helmet` |
| Night Vision Goggles | carved_pumpkin | `/function herdcraft:give/scp_cosmetics/night_vision_goggles` |
| Scientist Glasses | carved_pumpkin | `/function herdcraft:give/scp_cosmetics/scientist_glasses` |
| SCP-035 | carved_pumpkin | `/function herdcraft:give/scp_cosmetics/scp-035` |
| SCP-049-mask | carved_pumpkin | `/function herdcraft:give/scp_cosmetics/scp-049-mask` |
| SCP-178 | carved_pumpkin | `/function herdcraft:give/scp_cosmetics/scp-178` |
| SCP-286 | carved_pumpkin | `/function herdcraft:give/scp_cosmetics/scp-286` |
| Upgraded Gas Mask | carved_pumpkin | `/function herdcraft:give/scp_cosmetics/upgraded_gas_mask` |

## SCP Items (23 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| SCP-049-document | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-049-document` |
| SCP-079-document | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-079-document` |
| SCP-096-document | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-096-document` |
| SCP-1025 | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-1025` |
| SCP-1025-open | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-1025-open` |
| SCP-106-document | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-106-document` |
| SCP-173-document | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-173-document` |
| SCP-207 | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-207` |
| SCP-207-j | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-207-j` |
| SCP-286 | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-286` |
| SCP-330-blue-candy | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-330-blue-candy` |
| SCP-330-document | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-330-document` |
| SCP-330-green-candy | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-330-green-candy` |
| SCP-330-pink-candy | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-330-pink-candy` |
| SCP-330-purple-candy | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-330-purple-candy` |
| SCP-330-rainbow-candy | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-330-rainbow-candy` |
| SCP-330-red-candy | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-330-red-candy` |
| SCP-330-yellow-candy | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-330-yellow-candy` |
| SCP-500 | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-500` |
| SCP-714-document | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp-714-document` |
| SCP Adrenaline | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp_adrenaline` |
| SCP Medkit | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp_medkit` |
| SCP Painkillers | carrot_on_a_stick | `/function herdcraft:give/scp_items/scp_painkillers` |

## SCP Keycards (13 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Chaos Keycard | warped_fungus_on_a_stick | `/function herdcraft:give/scp_keycards/chaos_keycard` |
| Containment Engineer Keycard | warped_fungus_on_a_stick | `/function herdcraft:give/scp_keycards/containment_engineer_keycard` |
| Facility Guard Keycard | warped_fungus_on_a_stick | `/function herdcraft:give/scp_keycards/facility_guard_keycard` |
| Facility Manager Keycard | warped_fungus_on_a_stick | `/function herdcraft:give/scp_keycards/facility_manager_keycard` |
| Janitor Keycard | warped_fungus_on_a_stick | `/function herdcraft:give/scp_keycards/janitor_keycard` |
| Mtf Captain Keycard | warped_fungus_on_a_stick | `/function herdcraft:give/scp_keycards/mtf_captain_keycard` |
| Mtf Private Keycard | warped_fungus_on_a_stick | `/function herdcraft:give/scp_keycards/mtf_private_keycard` |
| Mtf Sergeant Keycard | warped_fungus_on_a_stick | `/function herdcraft:give/scp_keycards/mtf_sergeant_keycard` |
| O5 Keycard | warped_fungus_on_a_stick | `/function herdcraft:give/scp_keycards/o5_keycard` |
| Research Supervisor Keycard | warped_fungus_on_a_stick | `/function herdcraft:give/scp_keycards/research_supervisor_keycard` |
| Scientist Keycard | warped_fungus_on_a_stick | `/function herdcraft:give/scp_keycards/scientist_keycard` |
| SCP-714 | warped_fungus_on_a_stick | `/function herdcraft:give/scp_keycards/scp-714` |
| Zone Manager Keycard | warped_fungus_on_a_stick | `/function herdcraft:give/scp_keycards/zone_manager_keycard` |

## SCP Props (28 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Atm | ender_eye | `/function herdcraft:give/scp_props/atm` |
| SCP-079 | command_block | `/function herdcraft:give/scp_props/scp-079` |
| SCP-330 | golden_horse_armor | `/function herdcraft:give/scp_props/scp-330` |
| SCP-330 | ender_eye | `/function herdcraft:give/scp_props/scp-330` |
| SCP-door-1 | ender_eye | `/function herdcraft:give/scp_props/scp-door-1` |
| SCP-door-1-l | ender_eye | `/function herdcraft:give/scp_props/scp-door-1-l` |
| SCP-door-1-r | ender_eye | `/function herdcraft:give/scp_props/scp-door-1-r` |
| SCP Sign Clear | command_block | `/function herdcraft:give/scp_props/scp_sign_clear` |
| SCP Sign Ez | command_block | `/function herdcraft:give/scp_props/scp_sign_ez` |
| SCP Sign Hcz | command_block | `/function herdcraft:give/scp_props/scp_sign_hcz` |
| SCP Sign Lcz | command_block | `/function herdcraft:give/scp_props/scp_sign_lcz` |
| SCP Sign Security | command_block | `/function herdcraft:give/scp_props/scp_sign_security` |
| SCP Sign Surface | command_block | `/function herdcraft:give/scp_props/scp_sign_surface` |
| SCP Sign Warhead | command_block | `/function herdcraft:give/scp_props/scp_sign_warhead` |
| Sign-scp-035 | command_block | `/function herdcraft:give/scp_props/sign-scp-035` |
| Sign-scp-049 | command_block | `/function herdcraft:give/scp_props/sign-scp-049` |
| Sign-scp-049 | golden_horse_armor | `/function herdcraft:give/scp_props/sign-scp-049` |
| Sign-scp-079 | command_block | `/function herdcraft:give/scp_props/sign-scp-079` |
| Sign-scp-079 | golden_horse_armor | `/function herdcraft:give/scp_props/sign-scp-079` |
| Sign-scp-096 | command_block | `/function herdcraft:give/scp_props/sign-scp-096` |
| Sign-scp-096 | golden_horse_armor | `/function herdcraft:give/scp_props/sign-scp-096` |
| Sign-scp-106 | command_block | `/function herdcraft:give/scp_props/sign-scp-106` |
| Sign-scp-106 | golden_horse_armor | `/function herdcraft:give/scp_props/sign-scp-106` |
| Sign-scp-173 | command_block | `/function herdcraft:give/scp_props/sign-scp-173` |
| Sign-scp-173 | golden_horse_armor | `/function herdcraft:give/scp_props/sign-scp-173` |
| Sign-scp-330 | command_block | `/function herdcraft:give/scp_props/sign-scp-330` |
| Sign-scp-714 | command_block | `/function herdcraft:give/scp_props/sign-scp-714` |
| Sign-scp-914 | command_block | `/function herdcraft:give/scp_props/sign-scp-914` |

## Sebxter 3D Hats (9 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Sebxter Hat 1 | carved_pumpkin | `/function herdcraft:give/sebxter_3d_hats/hat_1` |
| Sebxter Hat 2 | carved_pumpkin | `/function herdcraft:give/sebxter_3d_hats/hat_2` |
| Sebxter Hat 3 | carved_pumpkin | `/function herdcraft:give/sebxter_3d_hats/hat_3` |
| Sebxter Hat 4 | carved_pumpkin | `/function herdcraft:give/sebxter_3d_hats/hat_4` |
| Sebxter Hat 5 | carved_pumpkin | `/function herdcraft:give/sebxter_3d_hats/hat_5` |
| Sebxter Hat 6 | carved_pumpkin | `/function herdcraft:give/sebxter_3d_hats/hat_6` |
| Sebxter Hat 7 | carved_pumpkin | `/function herdcraft:give/sebxter_3d_hats/hat_7` |
| Sebxter Hat 8 | carved_pumpkin | `/function herdcraft:give/sebxter_3d_hats/hat_8` |
| Sebxter Hat 9 | carved_pumpkin | `/function herdcraft:give/sebxter_3d_hats/hat_9` |

## Small Presents (16 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Small Present Black | carved_pumpkin | `/function herdcraft:give/small_presents/small_present_black` |
| Small Present Blue | carved_pumpkin | `/function herdcraft:give/small_presents/small_present_blue` |
| Small Present Brown | carved_pumpkin | `/function herdcraft:give/small_presents/small_present_brown` |
| Small Present Cyan | carved_pumpkin | `/function herdcraft:give/small_presents/small_present_cyan` |
| Small Present Gray | carved_pumpkin | `/function herdcraft:give/small_presents/small_present_gray` |
| Small Present Green | carved_pumpkin | `/function herdcraft:give/small_presents/small_present_green` |
| Small Present Light Blue | carved_pumpkin | `/function herdcraft:give/small_presents/small_present_light_blue` |
| Small Present Light Gray | carved_pumpkin | `/function herdcraft:give/small_presents/small_present_light_gray` |
| Small Present Lime | carved_pumpkin | `/function herdcraft:give/small_presents/small_present_lime` |
| Small Present Magenta | carved_pumpkin | `/function herdcraft:give/small_presents/small_present_magenta` |
| Small Present Orange | carved_pumpkin | `/function herdcraft:give/small_presents/small_present_orange` |
| Small Present Pink | carved_pumpkin | `/function herdcraft:give/small_presents/small_present_pink` |
| Small Present Purple | carved_pumpkin | `/function herdcraft:give/small_presents/small_present_purple` |
| Small Present Red | carved_pumpkin | `/function herdcraft:give/small_presents/small_present_red` |
| Small Present White | carved_pumpkin | `/function herdcraft:give/small_presents/small_present_white` |
| Small Present Yellow | carved_pumpkin | `/function herdcraft:give/small_presents/small_present_yellow` |

## Social (2 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| YT Gold Button | command_block | `/function herdcraft:give/social/yt_gold_button` |
| YT Silver Button | command_block | `/function herdcraft:give/social/yt_silver_button` |

## Specials (8 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Astronaut Helmet | carved_pumpkin | `/function herdcraft:give/specials/astronaut_helmet` |
| Halo | carved_pumpkin | `/function herdcraft:give/specials/halo` |
| Miner Helmet | carved_pumpkin | `/function herdcraft:give/specials/miner_helmet` |
| Party Hat | carved_pumpkin | `/function herdcraft:give/specials/party_hat` |
| Police Hat | carved_pumpkin | `/function herdcraft:give/specials/police_hat` |
| Sombrero | carved_pumpkin | `/function herdcraft:give/specials/sombrero` |
| Sunglasses | carved_pumpkin | `/function herdcraft:give/specials/sunglasses` |
| Wizard Hat | carved_pumpkin | `/function herdcraft:give/specials/wizard_hat` |

## Super Mario (8 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Brick Box | carved_pumpkin | `/function herdcraft:give/super_mario/brick_box` |
| Mario 1up | carved_pumpkin | `/function herdcraft:give/super_mario/mario_1up` |
| Mario Boo | carved_pumpkin | `/function herdcraft:give/super_mario/mario_boo` |
| Mario Coin | carved_pumpkin | `/function herdcraft:give/super_mario/mario_coin` |
| Mario Grow | carved_pumpkin | `/function herdcraft:give/super_mario/mario_grow` |
| Mario Shrink | carved_pumpkin | `/function herdcraft:give/super_mario/mario_shrink` |
| Prize Box | carved_pumpkin | `/function herdcraft:give/super_mario/prize_box` |
| Used Box | carved_pumpkin | `/function herdcraft:give/super_mario/used_box` |

## Tools (3 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Flashlight Off | carrot_on_a_stick | `/function herdcraft:give/tools/flashlight_off` |
| Flashlight On | carrot_on_a_stick | `/function herdcraft:give/tools/flashlight_on` |
| Object Remover | carrot_on_a_stick | `/function herdcraft:give/tools/object_remover` |

## Top Hats (2 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Small Top Hat | carved_pumpkin | `/function herdcraft:give/top_hats/small_top_hat` |
| Top Hat | carved_pumpkin | `/function herdcraft:give/top_hats/top_hat` |

## Villager Hats (9 items)

| Item | Base Item | Give Command |
|------|-----------|-------------|
| Armorer | carved_pumpkin | `/function herdcraft:give/villager_hats/armorer` |
| Butcher | carved_pumpkin | `/function herdcraft:give/villager_hats/butcher` |
| Cartographer | carved_pumpkin | `/function herdcraft:give/villager_hats/cartographer` |
| Farmer | carved_pumpkin | `/function herdcraft:give/villager_hats/farmer` |
| Fisherman | carved_pumpkin | `/function herdcraft:give/villager_hats/fisherman` |
| Fletcher | carved_pumpkin | `/function herdcraft:give/villager_hats/fletcher` |
| Librarian | carved_pumpkin | `/function herdcraft:give/villager_hats/librarian` |
| Shepherd | carved_pumpkin | `/function herdcraft:give/villager_hats/shepherd` |
| Weaponsmith | carved_pumpkin | `/function herdcraft:give/villager_hats/weaponsmith` |

---

## Raw Give Commands (Copy-Paste)

### Among Us
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/amongus_black",custom_name={text:"Amongus Black",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/amongus_blue",custom_name={text:"Amongus Blue",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/amongus_brown",custom_name={text:"Amongus Brown",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/amongus_cyan",custom_name={text:"Amongus Cyan",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/amongus_gray",custom_name={text:"Amongus Gray",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/amongus_green",custom_name={text:"Amongus Green",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/amongus_light_blue",custom_name={text:"Amongus Light Blue",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/amongus_light_gray",custom_name={text:"Amongus Light Gray",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/amongus_lime",custom_name={text:"Amongus Lime",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/amongus_magenta",custom_name={text:"Amongus Magenta",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/amongus_orange",custom_name={text:"Amongus Orange",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/amongus_pink",custom_name={text:"Amongus Pink",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/amongus_purple",custom_name={text:"Amongus Purple",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/amongus_red",custom_name={text:"Amongus Red",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/amongus_white",custom_name={text:"Amongus White",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/amongus_yellow",custom_name={text:"Amongus Yellow",italic:false}] 1
```

### Animals
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/bunny_ears",custom_name={text:"Bunny Ears",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/cat_ears",custom_name={text:"Cat Ears",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fox_ears",custom_name={text:"Fox Ears",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/owl_ears",custom_name={text:"Owl Ears",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/white_owl_ears",custom_name={text:"White Owl Ears",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/wolf_ears",custom_name={text:"Wolf Ears",italic:false}] 1
```

### Caps
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/cap_black",custom_name={text:"Cap Black",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/cap_blue",custom_name={text:"Cap Blue",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/cap_brown",custom_name={text:"Cap Brown",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/cap_cyan",custom_name={text:"Cap Cyan",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/cap_gray",custom_name={text:"Cap Gray",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/cap_green",custom_name={text:"Cap Green",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/cap_light_blue",custom_name={text:"Cap Light Blue",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/cap_light_gray",custom_name={text:"Cap Light Gray",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/cap_lime",custom_name={text:"Cap Lime",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/cap_magenta",custom_name={text:"Cap Magenta",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/cap_orange",custom_name={text:"Cap Orange",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/cap_pink",custom_name={text:"Cap Pink",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/cap_purple",custom_name={text:"Cap Purple",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/cap_red",custom_name={text:"Cap Red",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/cap_white",custom_name={text:"Cap White",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/cap_yellow",custom_name={text:"Cap Yellow",italic:false}] 1
```

### Christmas
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/candy_cane_green",custom_name={text:"Candy Cane Green",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/candy_cane_red",custom_name={text:"Candy Cane Red",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/christmas_tree_big",custom_name={text:"Christmas Tree Big",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/christmas_tree_little",custom_name={text:"Christmas Tree Little",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/christmas_tree_medium",custom_name={text:"Christmas Tree Medium",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/elf",custom_name={text:"Elf",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/elf_ears",custom_name={text:"Elf Ears",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/santa",custom_name={text:"Santa",italic:false}] 1
```

### Crowns
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/british_crown",custom_name={text:"British Crown",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/golden_crown",custom_name={text:"Golden Crown",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/king_crown",custom_name={text:"King Crown",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/silver_crown",custom_name={text:"Silver Crown",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/technoblade_crown",custom_name={text:"Technoblade Crown",italic:false}] 1
```

### FNAF
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/bonnie",custom_name={text:"Bonnie",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/bonnie_be",custom_name={text:"Bonnie Be",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/chica",custom_name={text:"Chica",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/chica_be",custom_name={text:"Chica Be",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/foxy",custom_name={text:"Foxy",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/foxy_be",custom_name={text:"Foxy Be",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/freddy_fazbear",custom_name={text:"Freddy Fazbear",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/freddy_fazbear_be",custom_name={text:"Freddy Fazbear Be",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/freddy_mask",custom_name={text:"Freddy Mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/golden_freddy",custom_name={text:"Golden Freddy",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/golden_freddy_no_eyes",custom_name={text:"Golden Freddy No Eyes",italic:false}] 1
```

### Fedoras
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/fedora_black",custom_name={text:"Fedora Black",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fedora_blue",custom_name={text:"Fedora Blue",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fedora_brown",custom_name={text:"Fedora Brown",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fedora_cyan",custom_name={text:"Fedora Cyan",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fedora_gray",custom_name={text:"Fedora Gray",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fedora_green",custom_name={text:"Fedora Green",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fedora_light_blue",custom_name={text:"Fedora Light Blue",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fedora_light_gray",custom_name={text:"Fedora Light Gray",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fedora_lime",custom_name={text:"Fedora Lime",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fedora_magenta",custom_name={text:"Fedora Magenta",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fedora_orange",custom_name={text:"Fedora Orange",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fedora_pink",custom_name={text:"Fedora Pink",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fedora_purple",custom_name={text:"Fedora Purple",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fedora_red",custom_name={text:"Fedora Red",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fedora_white",custom_name={text:"Fedora White",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fedora_yellow",custom_name={text:"Fedora Yellow",italic:false}] 1
```

### Fishing Rods
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/fishing_rod_amethyst",custom_name={text:"Fishing Rod Amethyst",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fishing_rod_diamond",custom_name={text:"Fishing Rod Diamond",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fishing_rod_emerald",custom_name={text:"Fishing Rod Emerald",italic:false}] 1
```

### Gaming Headsets
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/gaming_headset_black",custom_name={text:"Gaming Headset Black",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/gaming_headset_blue",custom_name={text:"Gaming Headset Blue",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/gaming_headset_brown",custom_name={text:"Gaming Headset Brown",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/gaming_headset_cyan",custom_name={text:"Gaming Headset Cyan",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/gaming_headset_gray",custom_name={text:"Gaming Headset Gray",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/gaming_headset_green",custom_name={text:"Gaming Headset Green",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/gaming_headset_light_blue",custom_name={text:"Gaming Headset Light Blue",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/gaming_headset_light_gray",custom_name={text:"Gaming Headset Light Gray",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/gaming_headset_lime",custom_name={text:"Gaming Headset Lime",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/gaming_headset_magenta",custom_name={text:"Gaming Headset Magenta",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/gaming_headset_orange",custom_name={text:"Gaming Headset Orange",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/gaming_headset_pink",custom_name={text:"Gaming Headset Pink",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/gaming_headset_purple",custom_name={text:"Gaming Headset Purple",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/gaming_headset_red",custom_name={text:"Gaming Headset Red",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/gaming_headset_rgb",custom_name={text:"Gaming Headset Rgb",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/gaming_headset_white",custom_name={text:"Gaming Headset White",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/gaming_headset_yellow",custom_name={text:"Gaming Headset Yellow",italic:false}] 1
```

### Hazbin Hotel
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/alastor_hair",custom_name={text:"Alastor Hair",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/adam_full_mask_hazbin",custom_name={text:"Adam Full Mask Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/adam_full_white_mask_hazbin",custom_name={text:"Adam Full White Mask Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/adam_halo_hazbin",custom_name={text:"Adam Halo Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/adam_halo_mask_hazbin",custom_name={text:"Adam Halo Mask Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/adam_mask_hazbin",custom_name={text:"Adam Mask Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/alastor_ears_hazbin",custom_name={text:"Alastor Ears Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/alastor_monocle_hazbin",custom_name={text:"Alastor Monocle Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/angel_dust_hair_hazbin",custom_name={text:"Angel Dust Hair Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/angel_dust_hair_sunglasses_hazbin",custom_name={text:"Angel Dust Hair Sunglasses Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/angel_dust_sunglasses_hazbin",custom_name={text:"Angel Dust Sunglasses Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/emily_halo_hazbin",custom_name={text:"Emily Halo Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/exorcist_full_mask_hazbin",custom_name={text:"Exorcist Full Mask Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/exorcist_halo_hazbin",custom_name={text:"Exorcist Halo Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/exorcist_halo_mask_hazbin",custom_name={text:"Exorcist Halo Mask Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/exorcist_mask_hazbin",custom_name={text:"Exorcist Mask Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/husk_ears_hat_hazbin",custom_name={text:"Husk Ears Hat Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/husk_ears_hazbin",custom_name={text:"Husk Ears Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/husk_eyebrows_hazbin",custom_name={text:"Husk Eyebrows Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/husk_full_hazbin",custom_name={text:"Husk Full Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/husk_hat_hazbin",custom_name={text:"Husk Hat Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/lucifer_hat_hazbin",custom_name={text:"Lucifer Hat Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/lute_full_mask_hazbin",custom_name={text:"Lute Full Mask Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/lute_halo_mask_hazbin",custom_name={text:"Lute Halo Mask Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/lute_mask_hazbin",custom_name={text:"Lute Mask Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/vaggie_loop_hazbin",custom_name={text:"Vaggie Loop Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/vaggie_x_hazbin",custom_name={text:"Vaggie X Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/vaggie_x_loop_hazbin",custom_name={text:"Vaggie X Loop Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/valentino_hat_hazbin",custom_name={text:"Valentino Hat Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/valentino_hat_sunglasses_hazbin",custom_name={text:"Valentino Hat Sunglasses Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/valentino_sunglasses_hazbin",custom_name={text:"Valentino Sunglasses Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/vox_full_hazbin",custom_name={text:"Vox Full Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/vox_hat_hazbin",custom_name={text:"Vox Hat Hazbin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/vox_head_hazbin",custom_name={text:"Vox Head Hazbin",italic:false}] 1
```

### Head Pickaxes
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/pickaxe_diamond",custom_name={text:"Pickaxe Diamond",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/pickaxe_gold",custom_name={text:"Pickaxe Gold",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/pickaxe_iron",custom_name={text:"Pickaxe Iron",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/pickaxe_netherite",custom_name={text:"Pickaxe Netherite",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/pickaxe_stone",custom_name={text:"Pickaxe Stone",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/pickaxe_wood",custom_name={text:"Pickaxe Wood",italic:false}] 1
```

### Headphones
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/headphones_black",custom_name={text:"Headphones Black",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/headphones_blue",custom_name={text:"Headphones Blue",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/headphones_brown",custom_name={text:"Headphones Brown",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/headphones_cyan",custom_name={text:"Headphones Cyan",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/headphones_gray",custom_name={text:"Headphones Gray",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/headphones_green",custom_name={text:"Headphones Green",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/headphones_light_blue",custom_name={text:"Headphones Light Blue",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/headphones_light_gray",custom_name={text:"Headphones Light Gray",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/headphones_lime",custom_name={text:"Headphones Lime",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/headphones_magenta",custom_name={text:"Headphones Magenta",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/headphones_orange",custom_name={text:"Headphones Orange",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/headphones_pink",custom_name={text:"Headphones Pink",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/headphones_plain",custom_name={text:"Headphones Plain",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/headphones_purple",custom_name={text:"Headphones Purple",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/headphones_red",custom_name={text:"Headphones Red",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/headphones_white",custom_name={text:"Headphones White",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/headphones_yellow",custom_name={text:"Headphones Yellow",italic:false}] 1
```

### HerdCraft Originals
```
give @s carved_pumpkin[item_model="herdcraft:carved_pumpkin/antennas",custom_name={text:"Antennas",italic:false}] 1
give @s pumpkin_pie[item_model="herdcraft:pumpkin_pie/cheese",custom_name={text:"Cheese",italic:false}] 1
give @s pumpkin_pie[item_model="herdcraft:pumpkin_pie/cheese_pizza",custom_name={text:"Cheese Pizza",italic:false}] 1
give @s pumpkin_pie[item_model="herdcraft:pumpkin_pie/cheesewheel",custom_name={text:"Cheesewheel",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:carved_pumpkin/gloria",custom_name={text:"Gloria",italic:false}] 1
give @s cooked_porkchop[item_model="herdcraft:cooked_porkchop/grilled_cheese",custom_name={text:"Grilled Cheese",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:carved_pumpkin/hat_green",custom_name={text:"Hat Green",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:carved_pumpkin/hat_santa",custom_name={text:"Hat Santa",italic:false}] 1
give @s beetroot_soup[item_model="herdcraft:beetroot_soup/landland_icecream",custom_name={text:"Landland Icecream",italic:false}] 1
give @s pumpkin_pie[item_model="herdcraft:pumpkin_pie/lollipop",custom_name={text:"Lollipop",italic:false}] 1
give @s shield[item_model="herdcraft:shield/mobile_router",custom_name={text:"Mobile Router",italic:false}] 1
give @s totem_of_undying[item_model="herdcraft:totem_of_undying/moos_extra_life",custom_name={text:"Moos Extra Life",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:carved_pumpkin/mooshroom_hat",custom_name={text:"Mooshroom Hat",italic:false}] 1
give @s totem_of_undying[item_model="herdcraft:totem_of_undying/party_popper",custom_name={text:"Party Popper",italic:false}] 1
give @s totem_of_undying[item_model="herdcraft:totem_of_undying/penguin",custom_name={text:"Penguin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:users/pengiswe/professor_hair",custom_name={text:"Professor Hair",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:carved_pumpkin/rainbow_pig_hat",custom_name={text:"Rainbow Pig Hat",italic:false}] 1
give @s totem_of_undying[item_model="herdcraft:totem_of_undying/totem_of_bobo",custom_name={text:"Totem Of Bobo",italic:false}] 1
```

### Large Presents
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/large_present_black",custom_name={text:"Large Present Black",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/large_present_blue",custom_name={text:"Large Present Blue",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/large_present_brown",custom_name={text:"Large Present Brown",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/large_present_cyan",custom_name={text:"Large Present Cyan",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/large_present_gray",custom_name={text:"Large Present Gray",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/large_present_green",custom_name={text:"Large Present Green",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/large_present_light_blue",custom_name={text:"Large Present Light Blue",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/large_present_light_gray",custom_name={text:"Large Present Light Gray",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/large_present_lime",custom_name={text:"Large Present Lime",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/large_present_magenta",custom_name={text:"Large Present Magenta",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/large_present_orange",custom_name={text:"Large Present Orange",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/large_present_pink",custom_name={text:"Large Present Pink",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/large_present_purple",custom_name={text:"Large Present Purple",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/large_present_red",custom_name={text:"Large Present Red",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/large_present_white",custom_name={text:"Large Present White",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/large_present_yellow",custom_name={text:"Large Present Yellow",italic:false}] 1
```

### Masks
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/alex_mask",custom_name={text:"Alex Mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/classic_enderman_mask",custom_name={text:"Classic Enderman Mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/creeper_mask",custom_name={text:"Creeper Mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/dali_mask",custom_name={text:"Dali Mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/drowned_mask",custom_name={text:"Drowned Mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/enderman_mask",custom_name={text:"Enderman Mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/herobrine_mask",custom_name={text:"Herobrine Mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/husk_mask",custom_name={text:"Husk Mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mask_blow",custom_name={text:"Mask Blow",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mask_bremu",custom_name={text:"Mask Bremu",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mask_eleven",custom_name={text:"Mask Eleven",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mask_jdabrowsky",custom_name={text:"Mask Jdabrowsky",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mask_jjayjoker",custom_name={text:"Mask Jjayjoker",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mask_ljay",custom_name={text:"Mask Ljay",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mask_madzik89",custom_name={text:"Mask Madzik89",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mask_mrboriiz",custom_name={text:"Mask Mrboriiz",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mask_multi",custom_name={text:"Mask Multi",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mask_ognisty",custom_name={text:"Mask Ognisty",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mask_pansmietanka",custom_name={text:"Mask Pansmietanka",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mask_polskipingwin",custom_name={text:"Mask Polskipingwin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mask_revisza",custom_name={text:"Mask Revisza",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mask_rezi",custom_name={text:"Mask Rezi",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mask_roxmb",custom_name={text:"Mask Roxmb",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mask_skkf",custom_name={text:"Mask Skkf",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mask_vertez",custom_name={text:"Mask Vertez",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/rock_mask",custom_name={text:"Rock Mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/skeleton_mask",custom_name={text:"Skeleton Mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/steve_mask",custom_name={text:"Steve Mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/stray_mask",custom_name={text:"Stray Mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/technoblade_mask",custom_name={text:"Technoblade Mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/villager_mask",custom_name={text:"Villager Mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/wither_mask",custom_name={text:"Wither Mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/wither_skeleton_mask",custom_name={text:"Wither Skeleton Mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/zombie_mask",custom_name={text:"Zombie Mask",italic:false}] 1
```

### Medium Presents
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/medium_present_black",custom_name={text:"Medium Present Black",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/medium_present_blue",custom_name={text:"Medium Present Blue",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/medium_present_brown",custom_name={text:"Medium Present Brown",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/medium_present_cyan",custom_name={text:"Medium Present Cyan",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/medium_present_gray",custom_name={text:"Medium Present Gray",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/medium_present_green",custom_name={text:"Medium Present Green",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/medium_present_light_blue",custom_name={text:"Medium Present Light Blue",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/medium_present_light_gray",custom_name={text:"Medium Present Light Gray",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/medium_present_lime",custom_name={text:"Medium Present Lime",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/medium_present_magenta",custom_name={text:"Medium Present Magenta",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/medium_present_orange",custom_name={text:"Medium Present Orange",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/medium_present_pink",custom_name={text:"Medium Present Pink",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/medium_present_purple",custom_name={text:"Medium Present Purple",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/medium_present_red",custom_name={text:"Medium Present Red",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/medium_present_white",custom_name={text:"Medium Present White",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/medium_present_yellow",custom_name={text:"Medium Present Yellow",italic:false}] 1
```

### Mini Blocks
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/mini_block_anvil",custom_name={text:"Mini Block Anvil",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mini_block_barrel",custom_name={text:"Mini Block Barrel",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mini_block_blast_furnace",custom_name={text:"Mini Block Blast Furnace",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mini_block_chest",custom_name={text:"Mini Block Chest",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mini_block_crafting",custom_name={text:"Mini Block Crafting",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mini_block_enchant",custom_name={text:"Mini Block Enchant",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mini_block_ender_chest",custom_name={text:"Mini Block Ender Chest",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mini_block_furnace",custom_name={text:"Mini Block Furnace",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mini_block_hopper",custom_name={text:"Mini Block Hopper",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mini_block_loom",custom_name={text:"Mini Block Loom",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mini_block_piston",custom_name={text:"Mini Block Piston",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mini_block_smoker",custom_name={text:"Mini Block Smoker",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mini_block_sticky_piston",custom_name={text:"Mini Block Sticky Piston",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mini_block_stonecutter",custom_name={text:"Mini Block Stonecutter",italic:false}] 1
```

### Money System
```
give @s command_block[item_model="herdcraft:boriiz/bucks_case_closed_empty",custom_name={text:"Bucks Case Closed Empty",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_case_closed_five_thousand",custom_name={text:"Bucks Case Closed Five Thousand",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_case_opened_empty",custom_name={text:"Bucks Case Opened Empty",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_case_opened_five_thousand",custom_name={text:"Bucks Case Opened Five Thousand",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_case_opened_four_thousand",custom_name={text:"Bucks Case Opened Four Thousand",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_case_opened_gold_ingot_five",custom_name={text:"Bucks Case Opened Gold Ingot Five",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_case_opened_gold_ingot_four",custom_name={text:"Bucks Case Opened Gold Ingot Four",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_case_opened_gold_ingot_one",custom_name={text:"Bucks Case Opened Gold Ingot One",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_case_opened_gold_ingot_seven",custom_name={text:"Bucks Case Opened Gold Ingot Seven",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_case_opened_gold_ingot_six",custom_name={text:"Bucks Case Opened Gold Ingot Six",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_case_opened_gold_ingot_three",custom_name={text:"Bucks Case Opened Gold Ingot Three",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_case_opened_gold_ingot_two",custom_name={text:"Bucks Case Opened Gold Ingot Two",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_case_opened_one_thousand",custom_name={text:"Bucks Case Opened One Thousand",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_case_opened_three_thousand",custom_name={text:"Bucks Case Opened Three Thousand",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_case_opened_two_thousand",custom_name={text:"Bucks Case Opened Two Thousand",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_fifty",custom_name={text:"Bucks Fifty",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_five",custom_name={text:"Bucks Five",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_five_hundred",custom_name={text:"Bucks Five Hundred",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_gold_ingot_five",custom_name={text:"Bucks Gold Ingot Five",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_gold_ingot_four",custom_name={text:"Bucks Gold Ingot Four",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_gold_ingot_one",custom_name={text:"Bucks Gold Ingot One",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_gold_ingot_seven",custom_name={text:"Bucks Gold Ingot Seven",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_gold_ingot_six",custom_name={text:"Bucks Gold Ingot Six",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_gold_ingot_three",custom_name={text:"Bucks Gold Ingot Three",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_gold_ingot_two",custom_name={text:"Bucks Gold Ingot Two",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_hundred",custom_name={text:"Bucks Hundred",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_one",custom_name={text:"Bucks One",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_stack",custom_name={text:"Bucks Stack",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_ten",custom_name={text:"Bucks Ten",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/bucks_ten_thousand",custom_name={text:"Bucks Ten Thousand",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/cash_bag",custom_name={text:"Cash Bag",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/coin_copper",custom_name={text:"Coin Copper",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/coin_gold",custom_name={text:"Coin Gold",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/coin_silver",custom_name={text:"Coin Silver",italic:false}] 1
```

### SCP Cosmetics
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/chaos_helmet",custom_name={text:"Chaos Helmet",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/gas_mask",custom_name={text:"Gas Mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mtf_helmet",custom_name={text:"Mtf Helmet",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/night_vision_goggles",custom_name={text:"Night Vision Goggles",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/scientist_glasses",custom_name={text:"Scientist Glasses",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/scp-035",custom_name={text:"SCP-035",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/scp-049-mask",custom_name={text:"SCP-049-mask",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/scp-178",custom_name={text:"SCP-178",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/scp-286",custom_name={text:"SCP-286",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/upgraded_gas_mask",custom_name={text:"Upgraded Gas Mask",italic:false}] 1
```

### SCP Items
```
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-049-document",custom_name={text:"SCP-049-document",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-079-document",custom_name={text:"SCP-079-document",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-096-document",custom_name={text:"SCP-096-document",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-1025",custom_name={text:"SCP-1025",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-1025-open",custom_name={text:"SCP-1025-open",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-106-document",custom_name={text:"SCP-106-document",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-173-document",custom_name={text:"SCP-173-document",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-207",custom_name={text:"SCP-207",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-207-j",custom_name={text:"SCP-207-j",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-286",custom_name={text:"SCP-286",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-330-blue-candy",custom_name={text:"SCP-330-blue-candy",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-330-document",custom_name={text:"SCP-330-document",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-330-green-candy",custom_name={text:"SCP-330-green-candy",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-330-pink-candy",custom_name={text:"SCP-330-pink-candy",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-330-purple-candy",custom_name={text:"SCP-330-purple-candy",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-330-rainbow-candy",custom_name={text:"SCP-330-rainbow-candy",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-330-red-candy",custom_name={text:"SCP-330-red-candy",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-330-yellow-candy",custom_name={text:"SCP-330-yellow-candy",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-500",custom_name={text:"SCP-500",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp-714-document",custom_name={text:"SCP-714-document",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp_adrenaline",custom_name={text:"SCP Adrenaline",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp_medkit",custom_name={text:"SCP Medkit",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/scp_painkillers",custom_name={text:"SCP Painkillers",italic:false}] 1
```

### SCP Keycards
```
give @s warped_fungus_on_a_stick[item_model="herdcraft:boriiz/chaos_keycard",custom_name={text:"Chaos Keycard",italic:false}] 1
give @s warped_fungus_on_a_stick[item_model="herdcraft:boriiz/containment_engineer_keycard",custom_name={text:"Containment Engineer Keycard",italic:false}] 1
give @s warped_fungus_on_a_stick[item_model="herdcraft:boriiz/facility_guard_keycard",custom_name={text:"Facility Guard Keycard",italic:false}] 1
give @s warped_fungus_on_a_stick[item_model="herdcraft:boriiz/facility_manager_keycard",custom_name={text:"Facility Manager Keycard",italic:false}] 1
give @s warped_fungus_on_a_stick[item_model="herdcraft:boriiz/janitor_keycard",custom_name={text:"Janitor Keycard",italic:false}] 1
give @s warped_fungus_on_a_stick[item_model="herdcraft:boriiz/mtf_captain_keycard",custom_name={text:"Mtf Captain Keycard",italic:false}] 1
give @s warped_fungus_on_a_stick[item_model="herdcraft:boriiz/mtf_private_keycard",custom_name={text:"Mtf Private Keycard",italic:false}] 1
give @s warped_fungus_on_a_stick[item_model="herdcraft:boriiz/mtf_sergeant_keycard",custom_name={text:"Mtf Sergeant Keycard",italic:false}] 1
give @s warped_fungus_on_a_stick[item_model="herdcraft:boriiz/o5_keycard",custom_name={text:"O5 Keycard",italic:false}] 1
give @s warped_fungus_on_a_stick[item_model="herdcraft:boriiz/research_supervisor_keycard",custom_name={text:"Research Supervisor Keycard",italic:false}] 1
give @s warped_fungus_on_a_stick[item_model="herdcraft:boriiz/scientist_keycard",custom_name={text:"Scientist Keycard",italic:false}] 1
give @s warped_fungus_on_a_stick[item_model="herdcraft:boriiz/scp-714",custom_name={text:"SCP-714",italic:false}] 1
give @s warped_fungus_on_a_stick[item_model="herdcraft:boriiz/zone_manager_keycard",custom_name={text:"Zone Manager Keycard",italic:false}] 1
```

### SCP Props
```
give @s ender_eye[item_model="herdcraft:boriiz/atm",custom_name={text:"Atm",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/scp-079",custom_name={text:"SCP-079",italic:false}] 1
give @s golden_horse_armor[item_model="herdcraft:boriiz/scp-330",custom_name={text:"SCP-330",italic:false}] 1
give @s ender_eye[item_model="herdcraft:boriiz/scp-330",custom_name={text:"SCP-330",italic:false}] 1
give @s ender_eye[item_model="herdcraft:boriiz/scp-door-1",custom_name={text:"SCP-door-1",italic:false}] 1
give @s ender_eye[item_model="herdcraft:boriiz/scp-door-1-l",custom_name={text:"SCP-door-1-l",italic:false}] 1
give @s ender_eye[item_model="herdcraft:boriiz/scp-door-1-r",custom_name={text:"SCP-door-1-r",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/scp_sign_clear",custom_name={text:"SCP Sign Clear",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/scp_sign_ez",custom_name={text:"SCP Sign Ez",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/scp_sign_hcz",custom_name={text:"SCP Sign Hcz",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/scp_sign_lcz",custom_name={text:"SCP Sign Lcz",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/scp_sign_security",custom_name={text:"SCP Sign Security",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/scp_sign_surface",custom_name={text:"SCP Sign Surface",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/scp_sign_warhead",custom_name={text:"SCP Sign Warhead",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/sign-scp-035",custom_name={text:"Sign-scp-035",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/sign-scp-049",custom_name={text:"Sign-scp-049",italic:false}] 1
give @s golden_horse_armor[item_model="herdcraft:boriiz/sign-scp-049",custom_name={text:"Sign-scp-049",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/sign-scp-079",custom_name={text:"Sign-scp-079",italic:false}] 1
give @s golden_horse_armor[item_model="herdcraft:boriiz/sign-scp-079",custom_name={text:"Sign-scp-079",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/sign-scp-096",custom_name={text:"Sign-scp-096",italic:false}] 1
give @s golden_horse_armor[item_model="herdcraft:boriiz/sign-scp-096",custom_name={text:"Sign-scp-096",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/sign-scp-106",custom_name={text:"Sign-scp-106",italic:false}] 1
give @s golden_horse_armor[item_model="herdcraft:boriiz/sign-scp-106",custom_name={text:"Sign-scp-106",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/sign-scp-173",custom_name={text:"Sign-scp-173",italic:false}] 1
give @s golden_horse_armor[item_model="herdcraft:boriiz/sign-scp-173",custom_name={text:"Sign-scp-173",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/sign-scp-330",custom_name={text:"Sign-scp-330",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/sign-scp-714",custom_name={text:"Sign-scp-714",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/sign-scp-914",custom_name={text:"Sign-scp-914",italic:false}] 1
```

### Sebxter 3D Hats
```
give @s carved_pumpkin[item_model="herdcraft:cosmetics/hats_1/hat_1",custom_name={text:"Sebxter Hat 1",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:cosmetics/hats_1/hat_2",custom_name={text:"Sebxter Hat 2",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:cosmetics/hats_1/hat_3",custom_name={text:"Sebxter Hat 3",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:cosmetics/hats_1/hat_4",custom_name={text:"Sebxter Hat 4",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:cosmetics/hats_1/hat_5",custom_name={text:"Sebxter Hat 5",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:cosmetics/hats_1/hat_6",custom_name={text:"Sebxter Hat 6",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:cosmetics/hats_1/hat_7",custom_name={text:"Sebxter Hat 7",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:cosmetics/hats_1/hat_8",custom_name={text:"Sebxter Hat 8",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:cosmetics/hats_1/hat_9",custom_name={text:"Sebxter Hat 9",italic:false}] 1
```

### Small Presents
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/small_present_black",custom_name={text:"Small Present Black",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/small_present_blue",custom_name={text:"Small Present Blue",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/small_present_brown",custom_name={text:"Small Present Brown",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/small_present_cyan",custom_name={text:"Small Present Cyan",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/small_present_gray",custom_name={text:"Small Present Gray",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/small_present_green",custom_name={text:"Small Present Green",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/small_present_light_blue",custom_name={text:"Small Present Light Blue",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/small_present_light_gray",custom_name={text:"Small Present Light Gray",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/small_present_lime",custom_name={text:"Small Present Lime",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/small_present_magenta",custom_name={text:"Small Present Magenta",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/small_present_orange",custom_name={text:"Small Present Orange",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/small_present_pink",custom_name={text:"Small Present Pink",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/small_present_purple",custom_name={text:"Small Present Purple",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/small_present_red",custom_name={text:"Small Present Red",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/small_present_white",custom_name={text:"Small Present White",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/small_present_yellow",custom_name={text:"Small Present Yellow",italic:false}] 1
```

### Social
```
give @s command_block[item_model="herdcraft:boriiz/yt_gold_button",custom_name={text:"YT Gold Button",italic:false}] 1
give @s command_block[item_model="herdcraft:boriiz/yt_silver_button",custom_name={text:"YT Silver Button",italic:false}] 1
```

### Specials
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/astronaut_helmet",custom_name={text:"Astronaut Helmet",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/halo",custom_name={text:"Halo",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/miner_helmet",custom_name={text:"Miner Helmet",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/party_hat",custom_name={text:"Party Hat",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/police_hat",custom_name={text:"Police Hat",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/sombrero",custom_name={text:"Sombrero",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/sunglasses",custom_name={text:"Sunglasses",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/wizard_hat",custom_name={text:"Wizard Hat",italic:false}] 1
```

### Super Mario
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/brick_box",custom_name={text:"Brick Box",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mario_1up",custom_name={text:"Mario 1up",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mario_boo",custom_name={text:"Mario Boo",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mario_coin",custom_name={text:"Mario Coin",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mario_grow",custom_name={text:"Mario Grow",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/mario_shrink",custom_name={text:"Mario Shrink",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/prize_box",custom_name={text:"Prize Box",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/used_box",custom_name={text:"Used Box",italic:false}] 1
```

### Tools
```
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/flashlight_off",custom_name={text:"Flashlight Off",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/flashlight_on",custom_name={text:"Flashlight On",italic:false}] 1
give @s carrot_on_a_stick[item_model="herdcraft:boriiz/object_remover",custom_name={text:"Object Remover",italic:false}] 1
```

### Top Hats
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/small_top_hat",custom_name={text:"Small Top Hat",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/top_hat",custom_name={text:"Top Hat",italic:false}] 1
```

### Villager Hats
```
give @s carved_pumpkin[item_model="herdcraft:boriiz/armorer",custom_name={text:"Armorer",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/butcher",custom_name={text:"Butcher",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/cartographer",custom_name={text:"Cartographer",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/farmer",custom_name={text:"Farmer",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fisherman",custom_name={text:"Fisherman",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/fletcher",custom_name={text:"Fletcher",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/librarian",custom_name={text:"Librarian",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/shepherd",custom_name={text:"Shepherd",italic:false}] 1
give @s carved_pumpkin[item_model="herdcraft:boriiz/weaponsmith",custom_name={text:"Weaponsmith",italic:false}] 1
```
